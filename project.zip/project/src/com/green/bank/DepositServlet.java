
package com.green.bank;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.green.bank.database.JDBC_Connect;
import com.green.bank.model.AccountModel;

@WebServlet("/Deposit")
public class DepositServlet extends HttpServlet {
	String account_no, username, password;
	Connection conn;
	Statement stmt;
	boolean pass_wrong = false;
	int current_amount, deposit_amount;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session= request.getSession(true);
		account_no = request.getParameter("account_no");
		username = request.getParameter("username");
		password = request.getParameter("password");
		deposit_amount = Integer.parseInt(request.getParameter("amount"));
		session.setAttribute("Acno",account_no);
		try {
			JDBC_Connect connect = new JDBC_Connect();
			conn = connect.getConnection();
			
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery("select * from account where id='" + account_no + "' and username='" + username
					+ "' and password='" + password + "'");

			if (!rs.isBeforeFirst()) {
				request.setAttribute("isPassOK", "No");
				RequestDispatcher rd = request.getRequestDispatcher("deposit.jsp");
				rd.forward(request, response);
			} else {
				System.out.println("I am in");
				ResultSet rs1 = stmt.executeQuery("select * from amount where id ='" + account_no + "'");

				while (rs1.next()) {
					current_amount = rs1.getInt(2);

					
				}

				current_amount += deposit_amount;

				PreparedStatement ps = conn.prepareStatement("update amount set amount=? where id= ?");
				ps.setInt(1, current_amount);
				ps.setString(2, account_no);
				ps.executeUpdate();
				System.out.println("the updated amount is  : "+(current_amount+deposit_amount));
				
				
				System.out.println("the deposit amount is : "+deposit_amount);
				System.out.println("the deposit balance  is : "+current_amount);
				PreparedStatement ps1 = conn.prepareStatement("insert into transaction(trno, debit,credit,balance,toaccno,fromaccno) values(trno.nextval, 0,?,?,?,?) ");
				ps1.setInt(1, deposit_amount);
				ps1.setInt(2, current_amount);
				ps1.setString(3, account_no);
				ps1.setString(4, account_no);
				ps1.executeUpdate();
				
				
				
				conn.close();
				
				RequestDispatcher rd = request.getRequestDispatcher("Deposit_process.jsp");
				rd.forward(request, response);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
